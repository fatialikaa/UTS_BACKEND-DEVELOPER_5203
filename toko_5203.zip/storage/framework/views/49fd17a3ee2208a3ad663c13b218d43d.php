<?php $__env->startSection('title', 'Produk'); ?>

<?php $__env->startSection('content'); ?>
    <h2 class="mb-3">Produk Kami</h2>

    
    <form action="" method="GET" class="mb-4">
        <div class="row g-2 align-items-center">
            <div class="col-md-4">
                <input type="text" name="nama" class="form-control" placeholder="Cari produk...">
            </div>
            <div class="col-md-2">
                <input type="number" name="min" class="form-control" placeholder="Harga min">
            </div>
            <div class="col-md-2">
                <input type="number" name="max" class="form-control" placeholder="Harga max">
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary w-100">Cari</button>
            </div>
            <div class="col-md-2">
                <a href="<?php echo e(url('/produk')); ?>" class="btn btn-outline-secondary w-100">Reset</a>
            </div>
        </div>
    </form>

    
    <h3 class="mb-3">Hasil Pencarian</h3>
    <div class="featured-products">
        <div class="row">
            <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-2 mb-4">
                <div class="card h-100 shadow-sm">
                    <img src="<?php echo e(asset('img/' . $item['gambar'])); ?>" class="card-img-top" alt="<?php echo e($item['nama']); ?>">
                    <div class="card-body d-flex flex-column">
                        <h5 class="card-title"><?php echo e($item['nama']); ?></h5>

                        <?php if($item['harga'] > 5000000): ?>
                            <span class="badge bg-dark text-light mb-2">Premium</span>
                        <?php elseif($item['harga'] >= 2000000): ?>
                            <span class="badge bg-info text-light mb-2">Menengah</span>
                        <?php else: ?>
                            <span class="badge bg-danger text-light mb-2">Ekonomis</span>
                        <?php endif; ?>

                        <p class="card-text text-primary font-weight-bold">
                            Rp <?php echo e(number_format($item['harga'], 0, ',', '.')); ?>

                        </p>

                        <?php if($item['diskon'] > 0): ?>
                            <span class="badge bg-success text-light mb-2">
                                Harga Diskon: <br/>
                                Rp <?php echo e(number_format($item['harga'] - ($item['harga'] * $item['diskon'] / 100), 0, ',', '.')); ?> <br/>
                                 (<?php echo e($item['diskon']); ?>% Off)
                            </span>
                        <?php endif; ?>


                        <a href="#" class="btn btn-primary mt-auto">View Details</a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\toko_5170\resources\views/front/produk.blade.php ENDPATH**/ ?>