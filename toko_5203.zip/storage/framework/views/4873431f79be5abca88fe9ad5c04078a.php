<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>

<div class="banner mb-4">
    <img src="<?php echo e(asset('img/banner.webp')); ?>" alt="Banner"
        class="img-fluid rounded shadow">
</div>


<h2 class="mb-3">Featured Products</h2>
<div class="featured-products">
    <div class="row">
        <!-- Data item produk -->

        <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3 mb-4">
            <div class="card h-100 shadow-sm">
                <img src="<?php echo e(asset('img/' . $item['gambar'])); ?>" class="card-img-top" alt="<?php echo e($item['nama']); ?>">
                <div class="card-body d-flex flex-column">
                    <h5 class="card-title"><?php echo e($item['nama']); ?></h5>

                    <?php if($item['harga'] > 5000000): ?>
                        <span class="badge bg-dark text-light mb-2">Premium</span>
                    <?php elseif($item['harga'] >= 2000000): ?>
                        <span class="badge bg-info text-light mb-2">Menengah</span>
                    <?php else: ?>
                        <span class="badge bg-danger text-light mb-2">Ekonomis</span>
                    <?php endif; ?>

                    <p class="card-text text-primary font-weight-bold">
                        Rp <?php echo e(number_format($item['harga'], 0, ',', '.')); ?>

                    </p>

                    <a href="#" class="btn btn-primary mt-auto">View Details</a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\toko_5203\resources\views/front/home.blade.php ENDPATH**/ ?>