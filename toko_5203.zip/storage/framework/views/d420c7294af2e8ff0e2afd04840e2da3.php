<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?> - Laravel Shop</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(url ('')); ?>">Adin's Shop</a>
            <div class="navbar-nav">
                <a class="nav-link" href="<?php echo e(url ('/home')); ?>">Home</a>
                <a class="nav-link" href="<?php echo e(url ('/produk')); ?>">Produk</a>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <footer class="bg-light text-center py-3 mt-4">
        <small>&copy; <?php echo e(date('Y')); ?> M. Nuraminudin</small>
    </footer>
</body>
</html>
<?php /**PATH E:\web-project\xampp-8-1\htdocs\toko_xxxx\resources\views/layouts/main.blade.php ENDPATH**/ ?>