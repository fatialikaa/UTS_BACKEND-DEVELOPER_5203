<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Produk;
use Illuminate\Support\Facades\Validator;

class ProdukController extends Controller
{
    // Halaman daftar produk staff
    public function indexStaff() {
        $produk = Produk::orderBy('id_produk', 'desc')->get();
        return view('produk.index', compact('produk')); // view khusus staff
    }

    // Halaman daftar produk admin
    public function indexAdmin() {
        $produk = Produk::orderBy('id_produk', 'desc')->get();
        return view('produk.index', compact('produk')); // pakai view staff tapi tanpa tombol CRUD
    }

    // Halaman create produk (staff)
    public function create() {
        return view('produk.create_produk');
    }

    public function edit($id)
    {
        $produk = Produk::findOrFail($id);
        return view('produk.edit_produk', compact('produk'));
    }

    public function destroy($id)
    {
        $produk = Produk::findOrFail($id);
        $produk->delete();
        return redirect()->route('staff.produk')->with('success', 'Produk berhasil dihapus.');
    }

    // Halaman daftar produk publik
    public function index() {
        // Contoh array produk dummy
        $produk = [
            ['nama' => 'Produk 1', 'harga' => 7500000, 'gambar' => 'produk1.jpg', 'diskon' => 10, 'stock' => 8],
            ['nama' => 'Produk 2', 'harga' => 4800000, 'gambar' => 'produk2.jpg', 'diskon' => 5, 'stock' => 7],
            ['nama' => 'Produk 3', 'harga' => 5200000, 'gambar' => 'produk3.jpg', 'diskon' => 0, 'stock' => 9],
            ['nama' => 'Produk 4', 'harga' => 150000,  'gambar' => 'produk4.jpg', 'diskon' => 20,'stock' => 5],
        ];

        return view('front.produk', compact('produk'));
    }

    // Halaman detail produk publik
    public function detail($nama) {
        return 'Ini halaman detail produk bernama '.$nama;
    }

    // Fitur pencarian produk publik
    public function cari_produk(Request $request) {
        $nama = $request->input('nama');
        $harga_min = $request->input('min');
        $harga_max = $request->input('max');

        $query = Produk::query();

        if (!empty($nama)) {
            $query->where('nama', 'like', '%' . $nama . '%');
        }

        if (!empty($harga_min)) {
            $query->where('harga', '>=', $harga_min);
        }

        if (!empty($harga_max)) {
            $query->where('harga', '<=', $harga_max);
        }

        $produk = $query->get();

        return view('front.produk', compact('produk', 'nama', 'harga_min', 'harga_max'));
    }

    // Simpan produk baru (staff)
    public function store(Request $request) {
        $validator = Validator::make($request->all(), [
            'nama'   => 'required|min:3|max:100',
            'harga'  => 'required|numeric|min:0',
            'diskon' => 'nullable|numeric|min:0|max:50',
            'stock'  => 'required|integer|min:0', // validasi stock
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }

        Produk::create([
            'nama'   => $request->nama,
            'harga'  => $request->harga,
            'diskon' => $request->diskon ?? 0,
            'stock'  => $request->stock,
        ]);

        return redirect()->route('staff.produk')
            ->with('success', 'Produk berhasil ditambahkan!');
    }

    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'nama' => 'required|min:3|max:100',
            'harga' => 'required|numeric|min:0',
            'diskon' => 'nullable|numeric|min:0|max:50',
            'stock'  => 'required|integer|min:0'
        ]);
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }
        $produk = Produk::findOrFail($id);
        $produk->update([
            'nama' => $request->nama,
            'harga' => $request->harga,
            'diskon' => $request->diskon ?? 0,
            'stock'  => $request->stock,
        ]);
        return redirect()->route('staff.produk')->with('success', 'Produk berhasil diperbarui!');
    }

    
}
